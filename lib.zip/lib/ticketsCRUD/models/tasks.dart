class Tasks{
  String? tasksname;
  String? tasksdescription;

  Tasks({this.tasksname,this.tasksdescription});
}